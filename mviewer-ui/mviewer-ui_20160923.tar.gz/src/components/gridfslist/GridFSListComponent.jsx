import React from 'react'
import GridFSListStyles from '../shared/listpanel.css'
import $ from 'jquery'
import GridFSItem from './GridFSItemComponent.jsx'
import NewBucket from '../newbucket/NewBucketComponent.jsx'
import SearchInput, {createFilter} from 'react-search-input'
import service from '../../gateway/service.js'

class GridFSList extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      gridfs:[],
      connectionId: this.props.propps.connectionId,
      dbStats: {},
      selectedDB: this.props.selectedDB,
      visible: false,
      selectedItem: null,
      loading: 'Loading',
      selectedCollection:null,
      searchTerm: ''
    }
  }

  success(calledFrom, data) {
    if(calledFrom == 'refreshCollectionList'){
      if(typeof(data.response.result) !== 'undefined'){
        this.setState({gridfs: data.response.result});
      }
      if(typeof(data.response.error) !== 'undefined'){
        if(data.response.error.code == 'DB_DOES_NOT_EXISTS'){
            this.props.refreshDb();
        }
      }
    }

    if(calledFrom == 'componentWillMount'){
      this.setState({gridfs: data.response.result});
    }

    if(calledFrom == 'componentWillReceiveProps'){
      this.setState({gridfs: data.response.result});
    }
  }

  failure() {

  }


  clickHandler (idx,fs) {
    this.setState({selectedCollection: idx});
    this.setState({ visible: false});
    this.props.setStates(fs);
    this.setState({selectedCollection : fs}, function(){
    });
  }

  refreshRespectiveData(newCollectionName) {
    this.setState({selectedCollection: newCollectionName});
    this.props.setStates(newCollectionName);
  }

  searchUpdated (term) {
    this.setState({searchTerm: term})
  }

  refreshCollectionList(db){
    var partialUrl = db +'/gridfs?connectionId=' + this.state.connectionId;
    var gridFSListCall = service('GET', partialUrl, '');
    gridFSListCall.then(this.success.bind(this, 'refreshCollectionList'), this.failure.bind(this, 'refreshCollectionList'));
  }

  componentWillMount(){
    var that = this;
    var partialUrl = this.props.selectedDB +'/gridfs?connectionId=' + this.state.connectionId;
    var gridFSListCall = service('GET', partialUrl, '');
    gridFSListCall.then(this.success.bind(this, 'componentWillMount'), this.failure.bind(this, 'componentWillMount'));
  }

  componentWillReceiveProps(nextProps) {
    var that = this;
    var partialUrl = nextProps.selectedDB +'/gridfs?connectionId=' + this.state.connectionId;
    var gridFSListCall = service('GET', partialUrl, '');
    gridFSListCall.then(this.success.bind(this, 'componentWillReceiveProps'), this.failure.bind(this, 'componentWillReceiveProps'));
  }

  render () {
    var that=this;
    var items=null;
    var filteredData = null;
    if (this.state.gridfs != undefined){
      filteredData = this.state.gridfs.filter(createFilter(this.state.searchTerm));
      var items = filteredData.map(function (item, idx) {
        var is_selected = that.state.selectedCollection == idx;
        return <GridFSItem
                key={item}
                name={item}
                dbName={this.state.selectedDB}
                onClick={this.clickHandler.bind(this,idx,item)}
                isSelected={that.state.selectedCollection==item}
                connectionId={this.state.connectionId}
                refreshCollectionList={this.refreshCollectionList.bind(this)}
                />;
        }.bind(this));
    }
      return (
        <div className={GridFSListStyles.menu} key = {this.props.visible}>
          <div className={(this.props.visible ?(this.state.visible ? GridFSListStyles.visible   : this.props.alignment): this.props.alignment ) }>
            <SearchInput className={GridFSListStyles.searchInput} onChange={this.searchUpdated.bind(this)} />
            <h5 className={GridFSListStyles.menuTitle}><NewBucket gridList= {this.state.gridfs} currentDb={this.props.selectedDB} currentItem="fs" connectionId={this.state.connectionId} refreshCollectionList={this.refreshCollectionList.bind(this)} refreshRespectiveData={this.refreshRespectiveData.bind(this)}></NewBucket></h5>
            {items}
          </div>
        </div>
      );
  }
}

export default GridFSList;
