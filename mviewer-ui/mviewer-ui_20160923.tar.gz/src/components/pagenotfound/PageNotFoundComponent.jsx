import React from 'react'

export default React.createClass({
  render() {
    return <div>Page Not Found</div>
  }
})